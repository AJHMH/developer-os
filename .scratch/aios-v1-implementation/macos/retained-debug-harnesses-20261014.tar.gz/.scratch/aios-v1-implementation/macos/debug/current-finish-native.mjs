// Serial receipt endorsement and public synthetic validation after owner-approved inference.
import {spawnSync} from 'node:child_process';
const base='.scratch/aios-v1-implementation/';
for(const [name,args] of [['public-capability',[]],['synthetic-task',[]],['online-qualification',['--approved-synthetic-unknown-usage']]]){
 console.log(JSON.stringify({stage:name,status:'starting',additionalProviderRequests:0}));
 const r=spawnSync(process.execPath,[base+'ticket25-macos-'+name+'-acceptance.mjs',...args],{stdio:'inherit',timeout:600000});
 if(r.error||r.status!==0){console.error(JSON.stringify({stage:name,status:'refused',errorCode:r.error?.code}));process.exit(r.status||1);}
}
const result=spawnSync(process.execPath,['scripts/assert-macos-qualification.mjs','--id','29727630-9a13-4050-a217-7a554b04448e','--state-dir','/Users/aaronhoward/.developer-os/ticket4-macos/state'],{stdio:'inherit',timeout:60000});
process.exitCode=result.status??1;
