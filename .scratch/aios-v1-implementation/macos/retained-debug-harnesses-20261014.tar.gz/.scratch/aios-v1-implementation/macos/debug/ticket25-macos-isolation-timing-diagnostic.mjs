// Historical diagnostic only; retained policy/source bindings must be checked before reuse. Grants no execution authority.
import cp from 'node:child_process';
import {syncBuiltinESMExports} from 'node:module';
const rawSpawn=cp.spawnSync;
cp.spawnSync=(exe,args,options)=>{const start=Date.now(),r=rawSpawn(exe,args,options);if(args?.includes('version')){const v={elapsedMs:Date.now()-start,deadlineMs:options.timeout,status:r.status,timedOut:r.error?.code==='ETIMEDOUT',connectionRefused:/connection refused/i.test(r.stderr??''),resourceRefused:/resource temporarily unavailable/i.test(r.stderr??'')};writeFileSync(new URL('../ticket25-version-preflight-failure.json',import.meta.url),JSON.stringify(v,null,2)+'\n');console.log(JSON.stringify(v));}return r;};
syncBuiltinESMExports();
import {spawnSync} from 'node:child_process';
import {writeFileSync} from 'node:fs';
import {NativePodmanDriver} from '../../../../dist/podman-native.js';
import {withHostCanary} from '../../../../dist/host-canary.js';
const n=new NativePodmanDriver('aios-macos-noshare','/Users/aaronhoward/.developer-os/ticket4-macos/state','/Users/aaronhoward/.developer-os/ticket4-macos/pins-ticket25-management-window-20261013.json');
const expected=n.policy('/Users/aaronhoward/.developer-os/ticket4-macos/input');
await withHostCanary(challenge=>{
 const {host,input}=n.invocation('isolate',{expected,challenge});
 const start=Date.now();
 const r=spawnSync(host.executable,['machine','ssh',n.machine,'python3'],{cwd:host.cwd,env:host.env,input,encoding:'utf8',timeout:90000,maxBuffer:1048576});
 let body={};try{body=JSON.parse(r.stdout)}catch{};
 const result={passed:body.passed===true,blockedStage:typeof body.blockedStage==='string'?body.blockedStage.slice(0,80):null,diagnostic:body.diagnostic,elapsedMs:Date.now()-start,status:r.status,timedOut:r.error?.code==='ETIMEDOUT',errorClasses:[...new Set(r.stderr.match(/\b(?:TimeoutExpired|ConnectionRefusedError|PermissionError|RuntimeError|AssertionError|FileNotFoundError)\b/g)??[])],returnedEvidence:!!r.stdout.trim()};
 writeFileSync(new URL('../ticket25-isolation-correct-policy-diagnostic.json',import.meta.url),JSON.stringify(result,null,2)+'\n');
 console.log(JSON.stringify(result));
},120000);
