// Historical diagnostic only; retained policy/source bindings must be checked before reuse. Grants no execution authority.
import assert from 'node:assert/strict';
import {writeFileSync} from 'node:fs';
import {NativePodmanDriver} from '../../../../dist/podman-native.js';
const n = new NativePodmanDriver('aios-macos-noshare','/Users/aaronhoward/.developer-os/ticket4-macos/state','/Users/aaronhoward/.developer-os/ticket4-macos/pins-ticket25-diagnostic2-20261013.json');
const r = await n.probeIsolation('/Users/aaronhoward/.developer-os/ticket4-macos/input','29727630-9a13-4050-a217-7a554b04448e');
const result={observedAt:new Date().toISOString(),isolation:r.passed,codex:r.codex};
writeFileSync(new URL('../ticket25-direct-diagnostic2.json',import.meta.url),JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify(result));
assert.equal(r.codex?.protocol,'passed');
