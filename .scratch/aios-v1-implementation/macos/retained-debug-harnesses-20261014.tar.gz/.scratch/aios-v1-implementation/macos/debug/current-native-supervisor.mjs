// Diagnostic lifecycle supervisor: no credentials, inference, or evidence overrides.
import {spawnSync,spawn} from 'node:child_process';
import {writeFileSync} from 'node:fs';
const podman='/opt/podman/bin/podman';
const started=spawnSync(podman,['machine','start','aios-macos-noshare'],{stdio:'inherit'});
if(started.status!==0)process.exit(1);
console.log('Dedicated VM started; keeping command session active.');
const {NativePodmanDriver}=await import('../../../../dist/podman-native.js');
const n=new NativePodmanDriver('aios-macos-noshare','/Users/aaronhoward/.developer-os/ticket4-macos/state','/Users/aaronhoward/.developer-os/ticket4-macos/pins-ticket25-clean-boot-20261013.json');
try{writeFileSync(new URL('../ticket25-clean-boot-enrollment.json',import.meta.url),JSON.stringify(n.pin('/Users/aaronhoward/.developer-os/ticket4-macos/input'),null,2)+'\n');console.log('Clean-boot source pins enrolled.');}catch(e){console.log('Clean-boot enrollment refused: '+e.message);}
process.stdin.resume();
