// Historical diagnostic only; retained policy/source bindings must be checked before reuse. Grants no execution authority.
import cp from 'node:child_process';
import {syncBuiltinESMExports} from 'node:module';
const originalSpawn=cp.spawnSync, versionTimes=[];
cp.spawnSync=(exe,args,options)=>{const started=Date.now(),r=originalSpawn(exe,args,options);if(args?.includes('version'))versionTimes.push({elapsedMs:Date.now()-started,deadlineMs:options.timeout,status:r.status,timedOut:r.error?.code==='ETIMEDOUT'});return r;};
syncBuiltinESMExports();
import {writeFileSync} from 'node:fs';
import {DeliveryController} from '../../../../dist/controller.js';
import {NativePodmanDriver} from '../../../../dist/podman-native.js';
import {PodmanHostAdapter} from '../../../../dist/podman-host.js';
import {NativeWindowsControls} from '../../../../dist/windows-controls.js';
const state='/Users/aaronhoward/.developer-os/ticket4-macos/state';
const policy='/Users/aaronhoward/.developer-os/ticket4-macos/pins-ticket25-management-window-20261013.json';
const n=new NativePodmanDriver('aios-macos-noshare',state,policy);
const c=new DeliveryController(state,{}, {worker:new PodmanHostAdapter({machine:n.machine,policyPath:policy,native:n,adversarial:true}),offline:n,windowsControls:new NativeWindowsControls(n)});
try {
 const d=await c.qualifyMacosControls('29727630-9a13-4050-a217-7a554b04448e');
 writeFileSync(new URL('../../ticket25-macos-controls-observation.json',import.meta.url),JSON.stringify({observedAt:new Date().toISOString(),controls:d.windowsControls,qualification:d.qualification},null,2)+'\n');
 writeFileSync(new URL('../ticket25-version-command-times.json',import.meta.url),JSON.stringify(versionTimes,null,2)+'\n');
 console.log(JSON.stringify({outcome:'passed'}));
} catch(e) {
 const allowed=['Boundary task refused','Missing orphan intent','Crash fixture exited early','Crash fixture unavailable','Crash fixture timed out','Unverified Windows shutdown','Competing owner dispatched','Revoked sender admitted','Orphan ownership released','Orphan recovery changed authority or work','Windows boundary probe refused','Unverified boundary observation'];
 const result={versionTimes,errorName:e.name,message:allowed.includes(e.message)?e.message:'unclassified',sourceFrames:[...e.stack.matchAll(/(?:controller|windows-controls|podman-native)\.js:\d+:\d+/g)].map(m=>m[0])};
 writeFileSync(new URL('../ticket25-controls-diagnostic.json',import.meta.url),JSON.stringify(result,null,2)+'\n');console.error(JSON.stringify(result));process.exitCode=1;
}
