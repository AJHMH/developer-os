// Historical diagnostic only; retained policy/source bindings must be checked before reuse. Grants no execution authority.
import {writeFileSync} from 'node:fs';
import {NativePodmanDriver} from '../../../../dist/podman-native.js';
import {PodmanHostAdapter} from '../../../../dist/podman-host.js';
import {DeliveryController} from '../../../../dist/controller.js';
const state='/Users/aaronhoward/.developer-os/ticket4-macos/state';
const policy='/Users/aaronhoward/.developer-os/ticket4-macos/pins-ticket25-management-window-20261013.json';
const n=new NativePodmanDriver('aios-macos-noshare',state,policy), original=n.observe.bind(n),attempts=[];
n.observe=(repo)=>{const start=Date.now();try{const r=original(repo);attempts.push({elapsedMs:Date.now()-start,observed:true});return r;}catch(e){attempts.push({elapsedMs:Date.now()-start,observed:false,message:['Observation unavailable','Native offline operation unavailable','Changed native executable','Unknown client version'].includes(e.message)?e.message:'unclassified'});throw e;}};
const c=new DeliveryController(state,{}, {worker:new PodmanHostAdapter({machine:n.machine,policyPath:policy,native:n})});
for(let i=0;i<3;i++){const d=await c.qualify('29727630-9a13-4050-a217-7a554b04448e');attempts.push({admitted:d.qualification.offlineAdmission.allowed});}
writeFileSync(new URL('../ticket25-admission-diagnostic.json',import.meta.url),JSON.stringify(attempts,null,2)+'\n');console.log(JSON.stringify(attempts));
