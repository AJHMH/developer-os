import subprocess,json,time
name='aios-ticket25-exec-headroom-diagnostic'
image='docker.io/library/alpine@sha256:24bb3511a0db7b5114a4aee033c65a8a4148f39b7b80a398e548546db967a36f'
def pod(*args):return subprocess.run(['podman',*args],stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=15)
assert pod('container','exists',name).returncode==1
try:
 r=pod('run','-d','--name',name,'--network=none','--read-only','--user=65534:65534','--cap-drop=all','--security-opt=no-new-privileges','--pids-limit=32',image,'/bin/sh','-c','for i in $(seq 1 31); do sleep 60 & done; wait')
 assert r.returncode==0
 time.sleep(1)
 r=pod('exec',name,'/bin/true')
 print(json.dumps(dict(saturatedExecExit=r.returncode,processLimitEvidence=('Resource temporarily unavailable' in r.stderr.decode() or 'resource temporarily unavailable' in r.stderr.decode()))))
 assert r.returncode!=0
finally:
 assert pod('rm','-f',name).returncode==0
