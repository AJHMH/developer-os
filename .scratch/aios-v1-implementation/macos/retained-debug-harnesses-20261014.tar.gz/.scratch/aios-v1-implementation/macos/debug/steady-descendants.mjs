// Native diagnostic regression. Uses the actual generated worker's descendant block.
import {spawnSync} from 'node:child_process';
import {writeFileSync} from 'node:fs';
import {NativePodmanDriver} from '../../../../dist/podman-native.js';
const n=new NativePodmanDriver('aios-macos-noshare','/Users/aaronhoward/.developer-os/ticket4-macos/state','/Users/aaronhoward/.developer-os/ticket4-macos/pins-ticket25-bounded-effective-20261014.json');
const input=n.invocation('enroll').input;
const request=JSON.parse(Buffer.from(input.match(/b64decode\('([^']+)'\)/)[1],'base64'));
const worker=request.worker.slice(request.worker.indexOf('sleep 600 &'),request.worker.indexOf('sleep 0.1'))+'wait\n';
const code=String.raw`
import subprocess,json,time,pathlib,uuid,base64
worker=base64.b64decode('WORKER').decode();name='aios-steady-descendants-'+str(uuid.uuid4())
def pod(*args):return subprocess.run(['podman',*args],stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=30)
counts=[];cg=None
try:
 r=pod('run','-d','--name',name,'--pull=never','--network=none','--read-only','--user=65534:65534','--cap-drop=all','--security-opt=no-new-privileges','--pids-limit=32','--memory=64m','IMAGE','/bin/sh','-c',worker);assert r.returncode==0
 pid=json.loads(pod('inspect',name).stdout)[0]['State']['Pid']
 cg=next(x[3:] for x in pathlib.Path('/proc/'+str(pid)+'/cgroup').read_text().splitlines() if x.startswith('0::/'))
 for i in range(3):
  time.sleep(0.25);counts.append(len(pathlib.Path('/sys/fs/cgroup'+cg+'/cgroup.procs').read_text().split()))
finally:
 assert pod('stop','--time','1',name).returncode==0
 state=json.loads(pod('inspect',name).stdout)[0]['State'];assert not state['Running'] and state['Pid']==0
 remaining=len(pathlib.Path('/sys/fs/cgroup'+cg+'/cgroup.procs').read_text().split()) if cg and pathlib.Path('/sys/fs/cgroup'+cg+'/cgroup.procs').exists() else 0
 assert remaining==0
 assert pod('rm',name).returncode==0
print(json.dumps(dict(steadyCensuses=counts,remainingProcesses=remaining)))
assert all(c>=8 for c in counts),'persistent descendant census below eight'
`.replace('WORKER',Buffer.from(worker).toString('base64')).replace('IMAGE',request.template);
const r=spawnSync('/opt/podman/bin/podman',['machine','ssh','aios-macos-noshare','python3'],{input:code,encoding:'utf8',timeout:60000});
if(r.stdout)writeFileSync(new URL('../ticket25-steady-descendants.json',import.meta.url),r.stdout);
console.log(r.stdout);console.error(r.stderr);process.exitCode=r.status??1;
