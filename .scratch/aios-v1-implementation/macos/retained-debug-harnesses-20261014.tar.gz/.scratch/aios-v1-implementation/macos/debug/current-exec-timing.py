import subprocess,json,time
name='aios-ticket25-exec-timing'
image='docker.io/library/alpine@sha256:24bb3511a0db7b5114a4aee033c65a8a4148f39b7b80a398e548546db967a36f'
def pod(*args):return subprocess.run(['podman',*args],stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=30)
assert pod('container','exists',name).returncode==1
try:
 assert pod('run','-d','--name',name,'--network=none','--read-only','--user=65534:65534','--cap-drop=all','--security-opt=no-new-privileges','--pids-limit=32',image,'sleep','120').returncode==0
 results=[]
 for i in range(5):
  start=time.monotonic();r=pod('exec',name,'/bin/true');results.append({'elapsedMs':round((time.monotonic()-start)*1000),'exitCode':r.returncode})
 print(json.dumps({'execTimings':results}))
finally:
 assert pod('rm','-f',name).returncode==0
