// Serial current-source public acceptance and plan preparation; no credential access/inference.
import {spawnSync} from 'node:child_process';
const base='.scratch/aios-v1-implementation/';
const id='29727630-9a13-4050-a217-7a554b04448e';
const policy='/Users/aaronhoward/.developer-os/ticket4-macos/pins-ticket25-memory-3072-20261014.json';
for(const [name,args] of [
 ['roundtrip',[id,policy]],['fencing',[id,policy]],['isolation',[id,policy]],['controls',[]],['gateway-inference',['--policy',policy]],
]){
 console.log(JSON.stringify({stage:name,status:'starting',inferenceExecuted:false}));
 const r=spawnSync(process.execPath,[base+'ticket25-macos-'+name+(name==='gateway-inference'?'.mjs':'-acceptance.mjs'),...args],{stdio:'inherit',timeout:600000});
 if(r.error||r.status!==0){console.error(JSON.stringify({stage:name,status:'refused',errorCode:r.error?.code}));process.exit(r.status||1);}
}
